package keys

const Foo = "foo"
