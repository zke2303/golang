// Licensed under the MIT license, see LICENSE file for details.

package qt

var (
	Prefixf        = prefixf
	TestingVerbose = &testingVerbose
)
