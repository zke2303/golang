package b

import "errors"

var ErrB = errors.New("b")

var NotErr = "not an error"
