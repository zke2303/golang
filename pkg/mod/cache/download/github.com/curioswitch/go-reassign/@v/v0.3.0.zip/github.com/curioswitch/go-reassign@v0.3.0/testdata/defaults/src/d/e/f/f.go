package f

import "errors"

var (
	ErrF = errors.New("f")
)
