package checker_test

/* canonical forms */
//nolint // reason
//nolint:gocritic // reason
//nolint:gocritic,whyNoLint // reason

/* variants we're okay enough with not to warn on; some other checker be strict about spacing */
//nolint //reason
//nolint//reason
// nolint // reason

//yeslint
