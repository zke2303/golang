package checker_test

/*! include an explanation for nolint directive */
//nolint

/*! include an explanation for nolint directive */
//nolint:gocritic

/*! include an explanation for nolint directive */
//nolint:gocritic,whyNoLint

/*! include an explanation for nolint directive */
// nolint

/*! include an explanation for nolint directive */
//nolint nonsense

/*! include an explanation for nolint directive */
//nolint //
