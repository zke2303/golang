// Package gocognit defines Analyzer other utilities to checks and calculate
// the complexity of function based on "cognitive complexity" methods.
package gocognit
