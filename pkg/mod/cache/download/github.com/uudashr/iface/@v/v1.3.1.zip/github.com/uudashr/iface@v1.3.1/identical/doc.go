// Package identical defines an Analyzer that identifies interfaces in the same
// package with identical methods or constraints.
package identical
