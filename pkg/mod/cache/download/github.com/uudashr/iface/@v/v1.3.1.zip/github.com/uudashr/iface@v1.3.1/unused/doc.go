// Package unused defines an Analyzer that indetifies interfaces that are not
// used anywhere in the same package where the interface is defined.
package unused
