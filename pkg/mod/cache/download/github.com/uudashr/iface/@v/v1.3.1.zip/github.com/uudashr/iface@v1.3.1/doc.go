// Package iface provides analyzers that designed to identify the incorrect use
// of interfaces, helping developers avoid interface pollution.
package iface
