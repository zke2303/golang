package iam

import "time"

type Clock interface {
	Now() time.Time
}
