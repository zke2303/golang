-- a.go --
package a

//lint:ignore test-check reason
func A_() {}
