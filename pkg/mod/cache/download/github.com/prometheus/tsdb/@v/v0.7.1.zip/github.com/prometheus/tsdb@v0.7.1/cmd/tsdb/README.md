TODO:
- [ ] add tabular output
- [ ] break commands in separate files
