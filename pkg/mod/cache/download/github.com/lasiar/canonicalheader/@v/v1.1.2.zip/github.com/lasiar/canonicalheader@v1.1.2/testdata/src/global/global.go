package global

import "net/http"

var header http.Header
