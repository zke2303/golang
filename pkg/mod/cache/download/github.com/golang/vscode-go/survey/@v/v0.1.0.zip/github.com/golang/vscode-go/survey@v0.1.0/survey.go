// The survey package holds the config.json file defining the Go Developer
// Survey configuration.
//
// The survey configuration specifies the survey's start and end dates, and the
// URL for the survey.
//
// This package contains no actual Go code, and exists only so the config.json
// file can be served by module proxies.
package survey
