// Package formatter implements the linter output formatters.
package formatter
