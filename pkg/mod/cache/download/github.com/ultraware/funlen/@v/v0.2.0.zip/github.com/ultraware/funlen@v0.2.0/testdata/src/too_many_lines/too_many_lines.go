package main

func main() { // want `Function 'main' is too long \(4 > 1\)`
	print("main!")
	print("is!")
	print("too!")
	print("long")
}
