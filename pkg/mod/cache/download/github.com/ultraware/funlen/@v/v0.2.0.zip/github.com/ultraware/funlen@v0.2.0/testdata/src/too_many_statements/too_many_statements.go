package main

func main() { // want `Function 'main' has too many statements \(2 > 1\)`
	print("Hello, world!")
	print("Hello, world!")
}
