package main

func main() {
	// Comment 1
	// Comment 2
	// Comment 3
	print("Hello, world!")
}

// Comment Doc
func unittest() {
	// Comment 1
	// Comment 2
	print("Hello, world!")
}

// Comment 3
