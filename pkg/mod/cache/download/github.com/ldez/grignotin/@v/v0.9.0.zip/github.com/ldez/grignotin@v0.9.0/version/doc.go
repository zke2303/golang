// Package version Gets information about releases and build.
package version
