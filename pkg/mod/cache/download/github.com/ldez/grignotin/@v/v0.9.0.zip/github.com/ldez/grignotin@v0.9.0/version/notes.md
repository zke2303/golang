endpoints:
- https://golang.org/dl/?mode=json
- https://golang.org/dl/?mode=json&include=all
- https://build.golang.org/?mode=json

sources:
- https://pkg.go.dev/golang.org/x/website/internal/dl
- https://cs.opensource.google/go/x/website/+/master:internal/dl/server.go
- https://github.com/golang/website/blob/master/internal/dl/dl.go
- previously in https://github.com/golang/tools/tree/master/godoc
