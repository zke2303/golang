Code borrowed from gci and modified to use new std packages.

https://github.com/daixiang0/gci/pull/227
