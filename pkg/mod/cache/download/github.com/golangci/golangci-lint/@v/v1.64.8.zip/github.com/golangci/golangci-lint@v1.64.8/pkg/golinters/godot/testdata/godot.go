//golangcitest:args -Egodot
package testdata

// want +2 "Comment should end in a period"

// Godot checks top-level comments
func Godot() {
	// nothing to do here
}
