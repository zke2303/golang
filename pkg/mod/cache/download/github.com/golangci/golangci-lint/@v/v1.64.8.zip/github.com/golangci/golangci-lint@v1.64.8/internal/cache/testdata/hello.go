package testdata

import "fmt"

func Hello() {
	fmt.Println("hello world")
}
