package cache

func SetSalt(b []byte) {
	hashSalt = b
}
