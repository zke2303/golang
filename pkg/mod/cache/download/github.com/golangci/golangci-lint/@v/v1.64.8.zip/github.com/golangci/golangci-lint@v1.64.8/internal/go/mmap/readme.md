# mmap

Extracted from `go/src/cmd/go/internal/mmap/` (related to `cache`).
This is just a copy of the Go code without any changes.

## History

- https://github.com/golangci/golangci-lint/pull/5100
  - Move package from `internal/mmap` to `internal/go/mmap`
- https://github.com/golangci/golangci-lint/pull/5098
  - sync with go1.23.2
  - sync with go1.22.8
  - sync with go1.21.13
  - sync with go1.20.14
  - sync with go1.19.13
