# analysisflags

Extracted from `/go/analysis/internal/analysisflags` (related to `checker`).
This is just a copy of the code without any changes.

## History

- sync with https://github.com/golang/tools/blob/v0.28.0
