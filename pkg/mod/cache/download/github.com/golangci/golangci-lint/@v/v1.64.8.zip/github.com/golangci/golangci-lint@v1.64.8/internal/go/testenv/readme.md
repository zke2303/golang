# testenv

Extracted from `go/src/internal/testenv/`.

Only the function `SyscallIsNotSupported` is extracted (related to `cache`).

## History

- https://github.com/golangci/golangci-lint/pull/5100
  - Move package from `internal/testenv` to `internal/go/testenv`
- https://github.com/golangci/golangci-lint/pull/5098
  - sync with go1.23.2
  - sync with go1.22.8
  - sync with go1.21.13
