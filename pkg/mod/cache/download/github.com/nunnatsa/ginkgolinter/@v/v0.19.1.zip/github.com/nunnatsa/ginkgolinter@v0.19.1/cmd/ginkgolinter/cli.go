package main

import "github.com/nunnatsa/ginkgolinter/cmd/ginkgolinter/cli"

func main() {
	cli.Main()
}
