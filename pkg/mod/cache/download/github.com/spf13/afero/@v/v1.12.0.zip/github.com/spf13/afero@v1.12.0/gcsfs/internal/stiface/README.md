# Copy of [google-cloud-go-testing](https://github.com/googleapis/google-cloud-go-testing)

This is a temporary copy of the [google-cloud-go-testing](https://github.com/googleapis/google-cloud-go-testing) library.
The library is deprecated and the code was copied here to drop it as a dependency (allowing to upgrade other library dependencies).
