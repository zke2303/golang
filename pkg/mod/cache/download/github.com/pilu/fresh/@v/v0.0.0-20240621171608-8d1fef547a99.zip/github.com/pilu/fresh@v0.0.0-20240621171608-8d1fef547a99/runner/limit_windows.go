// +build windows

package runner

func initLimit() {
}
