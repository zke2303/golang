package pkg

func Fn() {
	x := []string{}
	y := "not going in x"
	x = append(x, "not y")
	z := "string"
	x = append(x, "i don't care")
}
