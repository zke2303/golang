package main

//revive:disable
type none struct {
	Field int //TODO: Add JSON tag (Line 4)
	//toDO add more fields (Line 5)
	//second line of todo comment, should be skipped
}

/*
Some commnet
	TODO: multiline todo 1 (Line 11)



		TOdo multiline todo 2 (Line 15)
*/
