package addon

//revive:disable
import (
	"testing"
)

func TestNew(t *testing.T) {
	// TODO write test
}
