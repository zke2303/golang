//TODO: Add package documentation
//TODO: Write an actual application
package main

import "fmt"

//revive:disable
func main() {
	//FIXME: Spelling
	fmt.Println("Hello Warld")
}

/*
TODO: Multi line 1
TODO: Multi line 2
FIXME: Mutli line 3
*/
