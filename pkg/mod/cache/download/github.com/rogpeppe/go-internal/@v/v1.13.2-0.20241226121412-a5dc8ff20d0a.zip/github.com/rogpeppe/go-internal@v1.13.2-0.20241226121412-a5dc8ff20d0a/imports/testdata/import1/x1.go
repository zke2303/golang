//go:build blahblh && linux && !linux && windows && darwin
// +build blahblh,linux,!linux,windows,darwin

package x

import "import4"
