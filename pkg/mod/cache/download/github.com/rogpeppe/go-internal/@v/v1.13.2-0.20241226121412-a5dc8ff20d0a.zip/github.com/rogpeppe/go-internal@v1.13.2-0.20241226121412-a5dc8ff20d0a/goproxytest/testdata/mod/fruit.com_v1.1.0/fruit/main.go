package fruit

const Name = "Apple"
