//go:build tools

package quic

import (
	_ "go.uber.org/mock/mockgen"
)
