package téstdata // want `identifier "téstdata" contain non-ASCII character: U\+00E9 'é'`
