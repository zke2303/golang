// This package is great
package pkg

// MATCH:1 "package comment should be of the form"
