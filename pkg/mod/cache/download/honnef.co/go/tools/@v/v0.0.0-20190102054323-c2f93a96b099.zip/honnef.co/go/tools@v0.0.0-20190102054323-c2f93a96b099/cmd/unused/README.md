**Deprecated: unused has been merged into the staticcheck tool.**
