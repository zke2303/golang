package assist

type T1 struct {
	T2
}

type T2 struct {
	F int
}

var V T1
