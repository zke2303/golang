// Copyright 2024 The Go Authors. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

// Package http3 implements the HTTP/3 protocol.
//
// This package is a work in progress.
// It is not ready for production usage.
// Its API is subject to change without notice.
package http3
