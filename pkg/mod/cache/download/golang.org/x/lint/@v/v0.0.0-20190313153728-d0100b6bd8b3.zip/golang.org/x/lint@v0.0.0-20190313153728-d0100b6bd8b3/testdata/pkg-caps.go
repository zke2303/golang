// MixedCaps package name

// Package PkgName ...
package PkgName // MATCH /don't use MixedCaps in package name/
