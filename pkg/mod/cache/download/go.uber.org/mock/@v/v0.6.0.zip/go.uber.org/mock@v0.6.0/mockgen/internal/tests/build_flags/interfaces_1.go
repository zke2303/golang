//go:build tag1

package build_flags

type Interface interface {
	HelloWorld() string
}
