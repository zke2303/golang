//go:build tag2

package build_flags

type Interface interface {
	Foo()
}
