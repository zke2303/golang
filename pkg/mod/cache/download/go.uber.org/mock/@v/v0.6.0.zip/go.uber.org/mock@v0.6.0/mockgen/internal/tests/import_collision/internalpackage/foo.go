package internalpackage

type FooExported struct{}
