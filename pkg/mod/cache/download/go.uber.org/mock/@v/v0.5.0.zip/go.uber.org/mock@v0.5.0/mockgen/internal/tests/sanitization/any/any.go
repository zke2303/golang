package any

// Any is a type of a package that tests the sanitization of imported packages
// named any.
type Any struct{}
