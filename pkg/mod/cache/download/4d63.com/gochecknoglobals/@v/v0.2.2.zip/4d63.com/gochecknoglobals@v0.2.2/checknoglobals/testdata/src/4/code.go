package code

var theVar = 2 // want "theVar is a global variable"
