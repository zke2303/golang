package code

const constant = 0
