package code

var myVar = 0 // want "myVar is a global variable"
