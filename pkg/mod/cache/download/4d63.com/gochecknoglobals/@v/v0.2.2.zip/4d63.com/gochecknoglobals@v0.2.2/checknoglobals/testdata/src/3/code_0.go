package code

func someCode() bool {
	yourVar := true
	return yourVar
}

var theVar = true // want "theVar is a global variable"
